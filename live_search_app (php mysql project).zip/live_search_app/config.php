<?php

// Database Connection code Start
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "data_entry";

// Create connection
$db_conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if ($db_conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// echo "Connected successfully";
// Database Connection code End
?>