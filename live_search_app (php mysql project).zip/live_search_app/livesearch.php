<?php
include("config.php");

if(isset($_POST['input'])){
    $input = $_POST['input'];
    $query = "SELECT * FROM insert_data WHERE name LIKE '{$input}%' OR email LIKE '{$input}%'
    OR phone LIKE '{$input}%' OR dept LIKE '{$input}%'";
    $result = mysqli_query($db_conn,$query);

    if(mysqli_num_rows($result) > 0){?>

<table class="table table-border table-striped mt-4">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Department</th>
        </tr>
    <tbody>
        <?php
                while($row = mysqli_fetch_array($result)){
                    $id = $row['Id'];
                    $name = $row['name'];
                    $email = $row['email'];
                    $phone = $row['phone'];
                    $dept = $row['dept'];
                    ?>

        <tr>
            <td><?php echo $id; ?></td>
            <td><?php echo $name; ?></td>
            <td><?php echo $email; ?></td>
            <td><?php echo $phone; ?></td>
            <td><?php echo $dept; ?></td>
        </tr>

        <?php } ?>

    </tbody>
    </thead>

</table>

<?php
}
else{
    echo"<h5 class='text-danger text-center mt-3'>Data Not Found !</h5>";
} } ?>